import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parole',
  templateUrl: './parole.component.html',
  styleUrls: ['./parole.component.css']
})
export class ParoleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
