import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home';
import { AboutComponent } from './about';
import { ContactComponent } from './contact';
import { UniversitiesComponent } from './universities';
import { UniversityXComponent } from './university-x';


const routes: Routes = [
  { path: '',component: HomeComponent},
  { path: 'about',component: AboutComponent},
  { path: 'contact',component: ContactComponent},
  { path: 'universities',component: UniversitiesComponent},
  { path: 'university-x',component: UniversityXComponent},
  //otherwise redirect to home
  { path:'**', redirectTo:'' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule{}
