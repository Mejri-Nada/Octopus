import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { UniversitiesComponent } from './universities/universities.component';
import { NavbarComponent } from './home/navbar/navbar.component';
import { SearchBarComponent } from './home/search-bar/search-bar.component';
import { HorizLinesComponent } from './home/horiz-lines/horiz-lines.component';
import { QuoteComponent } from './home/quote/quote.component';
import { GridComponent } from './home/grid/grid.component';
import { CardsComponent } from './home/cards/cards.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ArrowComponent } from './home/arrow/arrow.component';
import { TopComponent } from './universities/top/top.component';
import { CollectionComponent } from './universities/collection/collection.component';
import { SliderComponent } from './universities/slider/slider.component';
import { UniversityXComponent } from './university-x/university-x.component';
import { Top1Component } from './university-x/top1/top1.component';
import { DescriptionComponent } from './university-x/description/description.component';
import { InfoBarComponent } from './university-x/info-bar/info-bar.component';
import { TableComponent } from './university-x/table/table.component';
import { RestaurantsComponent } from './university-x/restaurants/restaurants.component';
import { CoffeeShopsComponent } from './university-x/coffee-shops/coffee-shops.component';
import { SuperMarketsComponent } from './university-x/super-markets/super-markets.component';
import { HospitalsComponent } from './university-x/hospitals/hospitals.component';
import { Slider1Component } from './university-x/slider1/slider1.component';
import { PicComponent } from './about/pic/pic.component';
import { MissionComponent } from './about/mission/mission.component';
import { ParoleComponent } from './about/parole/parole.component';
import { GetComponent } from './about/get/get.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    UniversitiesComponent,
    NavbarComponent,
    SearchBarComponent,
    HorizLinesComponent,
    QuoteComponent,
    GridComponent,
    CardsComponent,
    HeaderComponent,
    FooterComponent,
    ArrowComponent,
    TopComponent,
    CollectionComponent,
    SliderComponent,
    UniversityXComponent,
    DescriptionComponent,
    InfoBarComponent,
    TableComponent,
    RestaurantsComponent,
    CoffeeShopsComponent,
    SuperMarketsComponent,
    HospitalsComponent,
    Top1Component,
    Slider1Component,
    PicComponent,
    MissionComponent,
    ParoleComponent,
    GetComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      // Register the ServiceWorker as soon as the app is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000'
    }),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


  