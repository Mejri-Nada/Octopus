import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HorizLinesComponent } from './horiz-lines.component';

describe('HorizLinesComponent', () => {
  let component: HorizLinesComponent;
  let fixture: ComponentFixture<HorizLinesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HorizLinesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HorizLinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
