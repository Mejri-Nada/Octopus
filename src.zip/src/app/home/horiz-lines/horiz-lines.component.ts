import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-horiz-lines',
  templateUrl: './horiz-lines.component.html',
  styleUrls: ['./horiz-lines.component.css']
})
export class HorizLinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
