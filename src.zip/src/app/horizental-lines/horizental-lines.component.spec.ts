import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HorizentalLinesComponent } from './horizental-lines.component';

describe('HorizentalLinesComponent', () => {
  let component: HorizentalLinesComponent;
  let fixture: ComponentFixture<HorizentalLinesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HorizentalLinesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HorizentalLinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
