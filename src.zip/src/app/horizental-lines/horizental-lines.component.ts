import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-horizental-lines',
  templateUrl: './horizental-lines.component.html',
  styleUrls: ['./horizental-lines.component.css']
})
export class HorizentalLinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
