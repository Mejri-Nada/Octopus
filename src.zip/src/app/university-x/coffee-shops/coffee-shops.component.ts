import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coffee-shops',
  templateUrl: './coffee-shops.component.html',
  styleUrls: ['./coffee-shops.component.css']
})
export class CoffeeShopsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
