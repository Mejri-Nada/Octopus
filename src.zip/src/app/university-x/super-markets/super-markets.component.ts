import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-super-markets',
  templateUrl: './super-markets.component.html',
  styleUrls: ['./super-markets.component.css']
})
export class SuperMarketsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
