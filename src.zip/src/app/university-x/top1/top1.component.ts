import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top1',
  templateUrl: './top1.component.html',
  styleUrls: ['./top1.component.css']
})
export class Top1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
