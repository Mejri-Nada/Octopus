import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UniversityXComponent } from './university-x.component';

describe('UniversityXComponent', () => {
  let component: UniversityXComponent;
  let fixture: ComponentFixture<UniversityXComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UniversityXComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UniversityXComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
