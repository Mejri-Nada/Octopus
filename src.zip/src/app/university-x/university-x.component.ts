import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-university-x',
  templateUrl: './university-x.component.html',
  styleUrls: ['./university-x.component.css']
})
export class UniversityXComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
